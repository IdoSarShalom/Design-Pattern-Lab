package test;


public class MyFuture<V> {
	private V v;


	// implement set()

	// implement thenDo()


	// implement finallyDo()
}
