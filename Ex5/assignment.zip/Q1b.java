package test;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Q1b {
	
	public void push(Runnable r){
	}
	
	public void close(){
	}
}