package test;

import java.util.concurrent.RecursiveTask;

public class ParMaxSearcher extends RecursiveTask<Integer> {

	private static final long serialVersionUID = 1L;
	

	@Override
	protected Integer compute() {
		return null;
	}	

}
