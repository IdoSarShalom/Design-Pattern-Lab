package test;

public class LFUCacheSearcher {

}
