package test;

public class Logger {

}
