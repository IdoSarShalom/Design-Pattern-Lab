package test;

public interface TextSearcher {

	Result search(String text, String rootPath);
}
