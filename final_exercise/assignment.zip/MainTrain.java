package test;

public class MainTrain {

	public static void main(String[] args) {
		System.out.println("your code will be checked manually after the deadline. please ignor the grade.");
		System.out.println("done");
	}

}
