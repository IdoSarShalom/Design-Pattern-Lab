package test;

public interface Stoppable {
	void stop();
}
