package test;



public class Pipe<E> implements Stoppable{

	// implement add(), filter(), map() , forEach()
	
	// and stop
	@Override
	public void stop() {
	}	
}
