package test;

import java.util.concurrent.Future;

public class ObservableFuture{
	// implement CTOR
	
	// implement get
}
