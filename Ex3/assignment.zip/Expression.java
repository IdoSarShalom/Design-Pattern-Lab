package test;

public interface Expression {
}
