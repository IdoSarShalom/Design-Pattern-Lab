package test;

public class Mul{
}
