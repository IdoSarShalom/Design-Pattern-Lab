package test;

public class BinaryExpression {
}
